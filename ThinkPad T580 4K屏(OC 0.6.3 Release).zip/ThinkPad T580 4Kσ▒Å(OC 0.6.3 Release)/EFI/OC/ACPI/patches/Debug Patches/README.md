# Debug

- [Dortania's OpenCore Debugging Guide](https://dortania.github.io/OpenCore-Install-Guide/troubleshooting/debug.html#file-swaps)